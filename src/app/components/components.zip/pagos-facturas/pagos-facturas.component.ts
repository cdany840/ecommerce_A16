import { Component } from '@angular/core';

@Component({
  selector: 'app-pagos-facturas',
  templateUrl: './pagos-facturas.component.html',
  styleUrls: ['./pagos-facturas.component.css']
})
export class PagosFacturasComponent {

}
